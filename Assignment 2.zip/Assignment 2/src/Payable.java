interface Payable {
    double getPaymentAmount();
}